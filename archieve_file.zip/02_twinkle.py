print('''Twinkle, twinkle,little star,
How I wonder what you are!
up above the world so high,
like a diamond in the sky!!''')